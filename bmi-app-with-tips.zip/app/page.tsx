"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import BMIForm from "@/components/bmi-form"
import BMIResult from "@/components/bmi-result"
import { calculateBMI, getBMICategory } from "@/lib/bmi-utils"

export default function Home() {
  const [bmiData, setBmiData] = useState<{
    bmi: number
    category: string
    height: number
    weight: number
  } | null>(null)

  const handleCalculate = (height: number, weight: number) => {
    const bmi = calculateBMI(weight, height)
    const category = getBMICategory(bmi)
    setBmiData({ bmi, category, height, weight })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-950 dark:to-slate-900 p-4 md:p-8">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 dark:text-slate-50 mb-2">BMI Calculator</h1>
          <p className="text-slate-600 dark:text-slate-400">Get personalized diet tips based on your BMI category</p>
        </div>

        {/* Main Content */}
        <div className="grid gap-6">
          <Card className="p-6 md:p-8 bg-white dark:bg-slate-800 border-0 shadow-lg">
            <BMIForm onCalculate={handleCalculate} />
          </Card>

          {bmiData && <BMIResult bmiData={bmiData} />}
        </div>
      </div>
    </div>
  )
}
