"use client"

import { Card } from "@/components/ui/card"
import { getBMIColor, getDietTips, getTargetBMI } from "@/lib/bmi-utils"

interface BMIResultProps {
  bmiData: {
    bmi: number
    category: string
    height: number
    weight: number
  }
}

export default function BMIResult({ bmiData }: BMIResultProps) {
  const { bmi, category, height, weight } = bmiData
  const color = getBMIColor(category)
  const tips = getDietTips(category)
  const targetBMI = getTargetBMI(category, height, weight)

  // Chart data for BMI ranges
  const chartData = [
    { label: "Underweight", value: 18.5, range: "< 18.5" },
    { label: "Normal", value: 24.9, range: "18.5-24.9" },
    { label: "Overweight", value: 29.9, range: "25-29.9" },
    { label: "Obese", value: 35, range: "≥ 30" },
  ]

  return (
    <div className="space-y-6">
      {/* BMI Score Card */}
      <Card className={`p-8 border-0 shadow-lg ${color.bg}`}>
        <div className="text-center">
          <p className={`text-sm font-semibold ${color.textSecondary} mb-2`}>Your BMI Score</p>
          <h2 className={`text-6xl font-bold ${color.text} mb-2`}>{bmi.toFixed(1)}</h2>
          <p className={`text-lg font-semibold ${color.text} mb-4`}>{category}</p>
          <div className={`inline-block px-4 py-2 rounded-full ${color.badge}`}>
            <p className={`text-sm font-medium ${color.badgeText}`}>
              Height: {(height * 100).toFixed(0)} cm | Weight: {weight.toFixed(1)} kg
            </p>
          </div>
        </div>
      </Card>

      {/* Target BMI */}
      <Card className="p-6 bg-white dark:bg-slate-800 border-0 shadow-lg">
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-50 mb-4">Target BMI Range to Maintain</h3>
        <div className="bg-gradient-to-r from-blue-50 to-blue-100 dark:from-blue-950/30 dark:to-blue-900/30 p-6 rounded-lg border border-blue-200 dark:border-blue-900">
          <p className="text-sm text-slate-600 dark:text-slate-400 mb-2">
            For your height ({(height * 100).toFixed(0)} cm), maintain:
          </p>
          <p className="text-3xl font-bold text-blue-600 dark:text-blue-400">BMI: 18.5 - 24.9</p>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-2">
            Healthy weight range: {(18.5 * height * height).toFixed(1)} - {(24.9 * height * height).toFixed(1)} kg
          </p>
        </div>
      </Card>

      {/* Diet Tips */}
      <Card className="p-6 bg-white dark:bg-slate-800 border-0 shadow-lg">
        <h3 className="text-lg font-bold text-slate-900 dark:text-slate-50 mb-6">🎯 Goal: {tips.goal}</h3>

        <div className="space-y-4 mb-8">
          <div>
            <h4 className="font-semibold text-slate-900 dark:text-slate-50 mb-3">💡 Recommended Tips:</h4>
            <ul className="space-y-2">
              {tips.tips.map((tip, index) => (
                <li key={index} className="flex gap-3 text-slate-700 dark:text-slate-300">
                  <span className="text-emerald-500 font-bold">✓</span>
                  <span>{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {tips.mealPlan && (
            <div>
              <h4 className="font-semibold text-slate-900 dark:text-slate-50 mb-3">🍽️ Meal Plan:</h4>
              <div className="bg-slate-50 dark:bg-slate-700/50 p-4 rounded-lg border border-slate-200 dark:border-slate-600">
                <p className="text-slate-700 dark:text-slate-300 font-medium">{tips.mealPlan}</p>
              </div>
            </div>
          )}
        </div>

        {/* Resources */}
        <div>
          <h4 className="font-semibold text-slate-900 dark:text-slate-50 mb-3">📚 Helpful Resources:</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {tips.resources.map((resource, index) => (
              <a
                key={index}
                href={resource.link}
                target="_blank"
                rel="noopener noreferrer"
                className="p-4 bg-slate-50 dark:bg-slate-700/50 border border-slate-200 dark:border-slate-600 rounded-lg hover:border-emerald-500 dark:hover:border-emerald-400 transition-colors group"
              >
                <p className="font-semibold text-slate-900 dark:text-slate-50 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                  {resource.name}
                </p>
                <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{resource.description}</p>
              </a>
            ))}
          </div>
        </div>
      </Card>

      {/* Medical Advice */}
      <Card className="p-6 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900 shadow-lg">
        <p className="text-sm text-amber-900 dark:text-amber-200">
          <span className="font-semibold">⚠️ Important:</span> This calculator provides general health information.
          Please consult a healthcare professional or dietician for personalized medical advice, especially if your BMI
          is above 35 or if you have existing health conditions.
        </p>
      </Card>
    </div>
  )
}
