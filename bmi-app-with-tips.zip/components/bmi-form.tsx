"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

interface BMIFormProps {
  onCalculate: (height: number, weight: number) => void
}

export default function BMIForm({ onCalculate }: BMIFormProps) {
  const [height, setHeight] = useState("")
  const [weight, setWeight] = useState("")
  const [unit, setUnit] = useState<"cm" | "m">("cm")
  const [error, setError] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    const heightNum = Number.parseFloat(height)
    const weightNum = Number.parseFloat(weight)

    if (!heightNum || !weightNum || heightNum <= 0 || weightNum <= 0) {
      setError("Please enter valid positive numbers")
      return
    }

    // Convert to meters if needed
    const heightInMeters = unit === "cm" ? heightNum / 100 : heightNum

    if (heightInMeters <= 0 || heightInMeters > 3) {
      setError("Please enter a valid height")
      return
    }

    onCalculate(heightInMeters, weightNum)
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Height Input */}
        <div className="space-y-2">
          <Label htmlFor="height" className="text-slate-700 dark:text-slate-300">
            Height <span className="text-slate-500">({unit})</span>
          </Label>
          <Input
            id="height"
            type="number"
            placeholder={unit === "cm" ? "170" : "1.70"}
            value={height}
            onChange={(e) => setHeight(e.target.value)}
            step={unit === "cm" ? "1" : "0.01"}
            className="border-slate-200 dark:border-slate-700"
          />
        </div>

        {/* Weight Input */}
        <div className="space-y-2">
          <Label htmlFor="weight" className="text-slate-700 dark:text-slate-300">
            Weight <span className="text-slate-500">(kg)</span>
          </Label>
          <Input
            id="weight"
            type="number"
            placeholder="70"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            step="0.1"
            className="border-slate-200 dark:border-slate-700"
          />
        </div>
      </div>

      {/* Unit Toggle */}
      <div className="flex gap-3 bg-slate-100 dark:bg-slate-700 p-2 rounded-lg">
        <button
          type="button"
          onClick={() => setUnit("cm")}
          className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
            unit === "cm"
              ? "bg-emerald-500 text-white"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
          }`}
        >
          Centimeters (cm)
        </button>
        <button
          type="button"
          onClick={() => setUnit("m")}
          className={`flex-1 py-2 px-4 rounded-md font-medium transition-colors ${
            unit === "m"
              ? "bg-emerald-500 text-white"
              : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200"
          }`}
        >
          Meters (m)
        </button>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-4 bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-900 rounded-lg">
          <p className="text-red-700 dark:text-red-400">{error}</p>
        </div>
      )}

      {/* Calculate Button */}
      <Button
        type="submit"
        className="w-full bg-emerald-500 hover:bg-emerald-600 text-white font-semibold py-3 rounded-lg transition-colors"
      >
        Calculate BMI
      </Button>
    </form>
  )
}
