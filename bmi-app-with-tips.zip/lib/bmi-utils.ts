export function calculateBMI(weight: number, heightInMeters: number): number {
  return weight / (heightInMeters * heightInMeters)
}

export function getBMICategory(bmi: number): string {
  if (bmi < 18.5) return "Underweight"
  if (bmi < 25) return "Normal Weight"
  if (bmi < 30) return "Overweight"
  return "Obese"
}

export function getBMIColor(category: string): {
  bg: string
  text: string
  textSecondary: string
  badge: string
  badgeText: string
} {
  switch (category) {
    case "Underweight":
      return {
        bg: "bg-gradient-to-br from-blue-100 to-cyan-100 dark:from-blue-950/40 dark:to-cyan-950/40",
        text: "text-blue-900 dark:text-blue-200",
        textSecondary: "text-blue-700 dark:text-blue-300",
        badge: "bg-blue-200 dark:bg-blue-900/50",
        badgeText: "text-blue-900 dark:text-blue-200",
      }
    case "Normal Weight":
      return {
        bg: "bg-gradient-to-br from-emerald-100 to-green-100 dark:from-emerald-950/40 dark:to-green-950/40",
        text: "text-emerald-900 dark:text-emerald-200",
        textSecondary: "text-emerald-700 dark:text-emerald-300",
        badge: "bg-emerald-200 dark:bg-emerald-900/50",
        badgeText: "text-emerald-900 dark:text-emerald-200",
      }
    case "Overweight":
      return {
        bg: "bg-gradient-to-br from-amber-100 to-orange-100 dark:from-amber-950/40 dark:to-orange-950/40",
        text: "text-amber-900 dark:text-amber-200",
        textSecondary: "text-amber-700 dark:text-amber-300",
        badge: "bg-amber-200 dark:bg-amber-900/50",
        badgeText: "text-amber-900 dark:text-amber-200",
      }
    case "Obese":
      return {
        bg: "bg-gradient-to-br from-red-100 to-rose-100 dark:from-red-950/40 dark:to-rose-950/40",
        text: "text-red-900 dark:text-red-200",
        textSecondary: "text-red-700 dark:text-red-300",
        badge: "bg-red-200 dark:bg-red-900/50",
        badgeText: "text-red-900 dark:text-red-200",
      }
    default:
      return {
        bg: "bg-slate-100 dark:bg-slate-700/50",
        text: "text-slate-900 dark:text-slate-50",
        textSecondary: "text-slate-700 dark:text-slate-300",
        badge: "bg-slate-200 dark:bg-slate-600",
        badgeText: "text-slate-900 dark:text-slate-50",
      }
  }
}

export function getTargetBMI(category: string, height: number, weight: number): { min: number; max: number } {
  const minBMI = 18.5
  const maxBMI = 24.9
  const minWeight = minBMI * height * height
  const maxWeight = maxBMI * height * height

  return { min: minWeight, max: maxWeight }
}

export function getDietTips(category: string): {
  goal: string
  tips: string[]
  mealPlan: string
  resources: Array<{ name: string; description: string; link: string }>
} {
  switch (category) {
    case "Underweight":
      return {
        goal: "Gain weight and improve nutrition",
        tips: [
          "Eat calorie-dense foods (nuts, seeds, avocados)",
          "Include protein-rich foods (chicken, fish, legumes, dairy)",
          "Eat 5-6 smaller meals throughout the day",
          "Include healthy fats (olive oil, coconut oil)",
          "Stay hydrated with water and nutritious drinks",
          "Exercise with strength training to build muscle",
        ],
        mealPlan:
          "¼ plate complex carbs (brown rice, quinoa) • ½ plate protein (meat, beans) • ¼ plate healthy fats (nuts, oils)",
        resources: [
          {
            name: "MyFitnessPal",
            description: "Track calories and nutrition",
            link: "https://www.myfitnesspal.com",
          },
          {
            name: "Nutrition.gov",
            description: "Government nutrition guidelines",
            link: "https://www.nutrition.gov",
          },
          {
            name: "Strength Training",
            description: "Build muscle with proper exercises",
            link: "https://www.acefitness.org",
          },
          {
            name: "Healthy Recipes",
            description: "Nutritious meal ideas",
            link: "https://www.allrecipes.com/gallery/healthy-recipes",
          },
        ],
      }

    case "Normal Weight":
      return {
        goal: "Maintain your current healthy BMI",
        tips: [
          "Continue balanced nutrition with all food groups",
          "Exercise regularly (150 min/week moderate activity)",
          "Maintain consistent eating habits",
          "Include a variety of vegetables and fruits daily",
          "Stay hydrated throughout the day",
          "Get adequate sleep (7-9 hours)",
        ],
        mealPlan: "½ plate vegetables/fruits • ¼ plate whole grains • ¼ plate lean protein • Limit processed foods",
        resources: [
          {
            name: "Harvard Health",
            description: "Evidence-based nutrition info",
            link: "https://www.health.harvard.edu",
          },
          {
            name: "MyPlate Plan",
            description: "USDA meal planning guide",
            link: "https://www.myplate.gov",
          },
          {
            name: "Fitness Trackers",
            description: "Monitor activity levels",
            link: "https://www.fitbit.com",
          },
          {
            name: "Wellness Resources",
            description: "Mental & physical health tips",
            link: "https://www.wholebodywellness.com",
          },
        ],
      }

    case "Overweight":
      return {
        goal: "Reduce weight gradually and lower health risks",
        tips: [
          "Begin with light cardio (walking, swimming, cycling)",
          "Focus on high-fiber foods (oats, vegetables, legumes)",
          "Avoid sugary drinks completely",
          "Reduce salt and processed food intake",
          "Portion control: use smaller plates",
          "Eat slowly and mindfully",
          "Include lean proteins at every meal",
          "Aim for 30 minutes of activity, 5 days/week",
        ],
        mealPlan: "½ plate vegetables • ¼ plate whole grains • ¼ plate lean protein • Limit oils and dressings",
        resources: [
          {
            name: "Weight Loss Plan",
            description: "Evidence-based weight loss strategies",
            link: "https://www.webmd.com/diet/healthy-weight-loss-for-life",
          },
          {
            name: "Calorie Counter",
            description: "Track daily intake",
            link: "https://www.calorieking.com.au",
          },
          {
            name: "Exercise Guide",
            description: "Safe workouts for weight loss",
            link: "https://www.acefitness.org",
          },
          {
            name: "Meal Plans",
            description: "Structured diet programs",
            link: "https://www.eatthismuch.com",
          },
        ],
      }

    case "Obese":
      return {
        goal: "Reduce weight significantly and improve health",
        tips: [
          "Consult a healthcare provider before starting exercise",
          "Start with low-impact activities (walking, water aerobics)",
          "Focus on whole foods and eliminate processed items",
          "Avoid sugary drinks, alcohol, and fried foods completely",
          "Drastically reduce salt and sugar intake",
          "Eat slowly and chew thoroughly",
          "Include protein at every meal for satiety",
          "Consider working with a registered dietician",
          "Aim for gradual weight loss (0.5-1 kg per week)",
          "Get adequate sleep and manage stress",
        ],
        mealPlan:
          "½ plate non-starchy vegetables • ¼ plate lean protein • ¼ plate whole grains • Healthy fats in moderation",
        resources: [
          {
            name: "Medical Weight Loss",
            description: "Professional weight management programs",
            link: "https://www.mayoclinic.org/healthy-lifestyle/weight-loss",
          },
          {
            name: "Dietician Finder",
            description: "Find registered dieticians",
            link: "https://www.eatright.org/find-a-nutrition-expert",
          },
          {
            name: "Support Groups",
            description: "Community support for weight loss",
            link: "https://www.obesityhelp.com",
          },
          {
            name: "Wellness Apps",
            description: "Comprehensive health tracking",
            link: "https://www.noom.com",
          },
        ],
      }

    default:
      return {
        goal: "Maintain healthy lifestyle",
        tips: [],
        mealPlan: "",
        resources: [],
      }
  }
}
